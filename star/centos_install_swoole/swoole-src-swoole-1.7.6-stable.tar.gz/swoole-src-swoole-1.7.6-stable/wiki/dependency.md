环境依赖
------

* 仅支持Linux操作系统，核心代码兼容FreeBSD，需要调整某些编译的参数和细节才能通过
* PHP5.2以上版本
* gcc4.2以上版本。核心代码兼容clang，需要关闭CPU亲和设置特性
* cmake2.4+,编译为libswoole.so作为C/C++库时，需要使用cmake



