onEvent
-----
在Controller进程内被调用。worker进程可以使用swoole_server_event向控制进程发送信息。

> PHP扩展内暂未提供