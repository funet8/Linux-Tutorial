swoole_client->close
-----
关闭连接，函数原型为：
```php
bool $swoole_client->close();
```
操作成功返回 **true**
> swoole_client对象在析构时会自动close