Swoole开源项目作者列表
=====

内核开发
------
* rango（韩天峰）mikan.tenny@gmail.com <http://swoole.sinaapp.com/>
* shenzhe (泽泽，半桶水)  shenzhe163@gmail.com
* recoye mail@recoye.com <http://www.recoye.com/>
* betashepherd（牧羊人）betashepherd@gmail.com 


文档编写
-----
* rango

