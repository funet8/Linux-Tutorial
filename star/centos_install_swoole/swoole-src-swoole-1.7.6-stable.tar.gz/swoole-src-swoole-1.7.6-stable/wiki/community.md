Swoole社区
------
* QQ群：321637118
* 微博群：[http://q.weibo.com/1827262](http://q.weibo.com/1827262)
* Gmail: mikan.tenny@gmail.com

邮件列表
-----

[![填写您的邮件地址，订阅我们的精彩内容：](http://rescdn.list.qq.com/zh_CN/htmledition/images/qunfa/manage/picMode_light_l.png)](http://list.qq.com/cgi-bin/qf_invite?id=70223bede10252e6973c1abf156f29638f8029299fe6c65e)

相关项目
-----
* [zphp](https://github.com/shenzhe/zphp)一个极轻的的，专用于游戏(社交，网页，移动)的服务器端开发框架.提供高性能实时通信方案。zphp使用swoole作为底层网络通信的框架。
* [swoole_framework](https://github.com/matyhtf/swoole_framework)基于swoole扩展，开发的纯PHP工业级WebServer。性能非常好。

贡献代码
-----
* 您可以发送邮件至 <team@swoole.com>
* Fork项目，并提交pull请求

